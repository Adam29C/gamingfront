import React from 'react'

const AdminsList = () => {
  return (
    <div>AdminsList</div>
  )
}

export default AdminsList