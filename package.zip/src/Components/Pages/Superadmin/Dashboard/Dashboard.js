import React from "react";
import Content from "../../../Layout/Content/Content";

const Dashboard = () => {
  return (
    <div>
      <Content title="Dashboard">
        <h1>hello world</h1>
      </Content>
    </div>
  );
};

export default Dashboard;
