import React from 'react'

const OtpProcess = () => {
  return (
    <div>OtpProcess</div>
  )
}

export default OtpProcess