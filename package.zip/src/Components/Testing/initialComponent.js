import React from "react";
import Content from "../../../Layout/Content/Content";

const Users = () => {
  return (
    <>
      <Content title="Add Users" col_size={12}>
        <h1>hello world</h1>
      </Content>
    </>
  );
};

export default Users;
